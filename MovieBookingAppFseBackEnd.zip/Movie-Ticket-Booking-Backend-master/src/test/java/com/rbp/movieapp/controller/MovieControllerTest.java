package com.rbp.movieapp.controller;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.kafka.clients.admin.NewTopic;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.rbp.movieapp.exception.MoviesNotFound;
import com.rbp.movieapp.models.Movie;
import com.rbp.movieapp.models.Ticket;
import com.rbp.movieapp.models.User;
import com.rbp.movieapp.payload.request.LoginRequest;
import com.rbp.movieapp.repository.UserRepository;
import com.rbp.movieapp.security.services.MovieService;

@ExtendWith(MockitoExtension.class)
class MovieControllerTest {

	@InjectMocks
	MovieController movieController;

	@Mock
	UserRepository userRepository;

	@Mock
	PasswordEncoder passwordEncoder;

	@Mock
	MovieService movieService;

	@Mock
	KafkaTemplate kafkaTemplate;

	@Mock
	NewTopic topic;

	@Test
	void testChangePassword() {
		LoginRequest request = new LoginRequest();
		request.setLoginId("admin");
		request.setPassword("password");
		User user = new User();
		Optional<User> user1 = Optional.of(user);
		doReturn(user1).when(userRepository).findByLoginId("admin");
		doReturn("admin").when(passwordEncoder).encode(request.getPassword());
		movieController.changePassword(request, "admin");
	}

	@Test
	void testGetAllMovies() {
		List<Movie> movieList = new ArrayList<>();
		Movie movie = new Movie();
		movieList.add(movie);
		doReturn(movieList).when(movieService).getAllMovies();
		movieController.getAllMovies();
	}

	@Test
	void testGetAllMoviesEmpty() {
		List<Movie> movieList = new ArrayList<>();
		doReturn(movieList).when(movieService).getAllMovies();
		assertThrows(MoviesNotFound.class, () -> movieController.getAllMovies());

	}

	@Test
	void testGetMovieByName() {
		List<Movie> movieList = new ArrayList<>();
		Movie movie = new Movie();
		movieList.add(movie);
		doReturn(movieList).when(movieService).getMovieByName("mersal");
		movieController.getMovieByName("mersal");
	}

	@Test
	void testGetMovieByNameElse() {
		List<Movie> movieList = new ArrayList<>();
		doReturn(movieList).when(movieService).getMovieByName("mersal");
		assertThrows(MoviesNotFound.class, () -> movieController.getMovieByName("mersal"));
	}

	@Test
	void testBookTickets() {

		Ticket ticket = new Ticket();
		ticket.setMovieName("mersa");
		ticket.setTheatreName("AGS;");
		ticket.setNoOfTickets(1);
		List<String> seatNum = new ArrayList<>();
		seatNum.add("b1");
		ticket.setSeatNumber(seatNum);

		List<Ticket> allTickets = new ArrayList<>();
		Ticket ticket1 = new Ticket();
		ticket1.setMovieName("mersal");
		ticket1.setTheatreName("AGS;");
		ticket1.setNoOfTickets(8);
		List<String> seatNumber = new ArrayList<>();
		seatNumber.add("a1");
		ticket1.setSeatNumber(seatNumber);
		allTickets.add(ticket1);
		doReturn(allTickets).when(movieService).findSeats("mersal", ticket.getTheatreName());
		List<Movie> availableMovies = new ArrayList<>();
		Movie movie = new Movie();
		movie.setMovieName("mersal");
		movie.setNoOfTicketsAvailable(7);
		availableMovies.add(movie);
		doReturn(availableMovies).when(movieService).findAvailableTickets("mersal", ticket.getTheatreName());
		kafkaTemplate.send(topic.name(), "Movie ticket booked. " + "Booking Details are: " + ticket);
		movieController.bookTickets(ticket, "mersal");
	}

	@Test
	void testGetAllBookedTickets() {
		List<Ticket> ticketList = new ArrayList<>();
		doReturn(ticketList).when(movieService).getAllBookedTickets("mersal");
		movieController.getAllBookedTickets("mersal");
	}

	@Test
	void testUpdateTicketsStatus() {
		List<Movie> availableMovies = new ArrayList<>();
		Movie movie = new Movie();
		movie.setTheatreName("ags");
		availableMovies.add(movie);
		doReturn(availableMovies).when(movieService).findAvailableTickets("mersal", movie.getTheatreName());
		kafkaTemplate.send(topic.name(), "tickets status upadated by the Admin for movie " + "mersal");
		movieController.updateTicketsStatus(movie, "mersal", "available");
	}

	@Test
	void testUpdateTicketsStatusEmpty() {
		Movie movie = new Movie();
		movie.setTheatreName("ags");
		List<Movie> availableMovies = new ArrayList<>();
		doReturn(availableMovies).when(movieService).findAvailableTickets("mersal", movie.getTheatreName());
		kafkaTemplate.send(topic.name(), "New Movie added by the Admin.\nDetails: \n" + movie);
		movieController.updateTicketsStatus(movie, "mersal", "available");
	}

	@Test
	void testDeleteMovie() {
		List<Movie> availableMovies = new ArrayList<>();
		Movie movie = new Movie();
		availableMovies.add(movie);
		doReturn(availableMovies).when(movieService).findByMovieName("mersal");
		kafkaTemplate.send(topic.name(), "Movie Deleted by the Admin. " + "mersal" + " is now not available");
		movieController.deleteMovie("mersal");
	}

	@Test
	void testDeleteMovieEmpty() {
		List<Movie> availableMovies = new ArrayList<>();
		doReturn(availableMovies).when(movieService).findByMovieName("mersal");
		assertThrows(MoviesNotFound.class, () -> movieController.deleteMovie("mersal"));
	}
}
