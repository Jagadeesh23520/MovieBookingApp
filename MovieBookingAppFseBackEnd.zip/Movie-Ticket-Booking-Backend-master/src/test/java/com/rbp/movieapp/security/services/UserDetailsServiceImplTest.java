package com.rbp.movieapp.security.services;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.rbp.movieapp.models.User;
import com.rbp.movieapp.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
class UserDetailsServiceImplTest {

	@InjectMocks
	UserDetailsServiceImpl userDetailsServiceImpl;

	@Mock
	UserRepository userRepository;

	@Test
	void testLoadUserByUsername() {

		User user = new User();
		Optional<User> userOpt = Optional.of(user);
		doReturn(userOpt).when(userRepository).findByLoginId("test");
		userDetailsServiceImpl.loadUserByUsername("test");
	}

	@Test
	void testLoadUserByUsernameEmpty() {

		assertThrows(UsernameNotFoundException.class, () -> userDetailsServiceImpl.loadUserByUsername("test"));
	}

}
